package fibonacci;
import java.util.Scanner;

public class Fibonacci{

	public static void main(String[] args){
		Scanner s = new Scanner(System.in);
		System.out.println(fiboRecur(s.nextInt()));
	}
	
	public static int Fibonacci(int pos) { //fibonacci interativo
		int[] fibo = new int[pos];
		fibo[0] = 0;
		fibo[1] = 1;
		
		for (int i = 2; i < fibo.length; i++){
			fibo[i] = fibo[i-1] + fibo[i-2];
		}
		
		return fibo[pos-1];
	}
	
	public static int fiboRecur(int posicao){  //Usando recursividade
		if(posicao == 1) return 0;
		else if(posicao == 2) return 1;
		return (fiboRecur(posicao-1) + fiboRecur(posicao-2));
	}
}