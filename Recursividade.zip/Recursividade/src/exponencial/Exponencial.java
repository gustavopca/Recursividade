package exponencial;

	import java.util.Scanner;

	public class Exponencial {

		public static void main(String[] args){
			Scanner s = new Scanner(System.in);
			System.out.println(exponRecur(s.nextInt(),s.nextInt()));
		}
		
		//Exponencial interativo
		public static int expon(int x, int y){
			int expon = 1;
			if(y < 0 || ((x == 0) && (y == 0))) return -1;
			else if(y == 0) return 1;
			
			for (int i = 0; i < y; i++){
				expon = expon * x;
			}
			return expon;
		}
		//Usando recursividade
		public static int exponRecur(int x,int y){
			if(y < 0 || ((x == 0) && (y == 0))) return -1;
			else if(y == 0) return 1;
			return (x * exponRecur(x,(y-1)));
		}
	}
