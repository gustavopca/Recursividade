package fatorial;

import java.util.Scanner;

public class Fatorial{
	public static void main(String[] args){
		Scanner s = new Scanner (System.in);
		int x= s.nextInt();
		System.out.println("Fatorial de " + x + " = " + CalcularFatorial(x));
	}
	public static int CalcularFatorial(int n) {
		if(n != 1) n = n * CalcularFatorial((n -1));
		return n;
	}
}